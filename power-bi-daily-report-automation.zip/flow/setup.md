# Recreate the portfolio demo

The sample queries use DAX DATATABLE with fictional figures. The reporting date advances with the clock; the example figures are deliberately fixed. The included HTML and PDF previews illustrate 22 November 2026. The repository is a source example for manual setup.

1. Create a scheduled cloud flow. Set Recurrence to every 1 day, India Standard Time, hour 9, minute 0.
2. Add a Compose action named ReportDate with the expression below.
3. Add two Power BI **Run a query against a dataset** actions named Sales and Orders. Select a workspace and semantic model you have permission to query. Paste the matching file from queries into each action.
4. Each demo query returns one row containing a complete HTML document. Use the Sales expression below as the file content of a OneDrive for Business Create file action. For Orders substitute Orders for Sales.
5. Create one HTML file per report in an existing folder in your own drive. Use the filename pattern below. For the second report substitute Orders for Sales.
6. For each HTML file, use OneDrive Convert file with its Id and target type PDF. Save the returned File content using Create file and the same filename pattern ending in .pdf.
7. In your authorised email connector, set your own test address as recipient. Add two attachments, using Name from the corresponding saved PDF and File content from its conversion. Verify both attachments open and show the reporting date in the email subject before enabling scheduled delivery.

**ReportDate**

```text
formatDateTime(addDays(convertTimeZone(utcNow(),'UTC','India Standard Time'),-1),'yyyy-MM-dd')
```

**Sales HTML content**

```text
first(body('Sales')?['firstTableRows'])?['[Html]']
```

**Dated filename**

```text
concat('Daily Sales Overview - ',formatDateTime(outputs('ReportDate'),'dd MMMM yyyy'),'.html')
```

**Example subject**

```text
concat('Sales and Orders Overview - ',formatDateTime(outputs('ReportDate'),'dd MMMM yyyy'))
```

Expressions assume the internal action names shown above. Select the matching action output in your designer if your names differ.
